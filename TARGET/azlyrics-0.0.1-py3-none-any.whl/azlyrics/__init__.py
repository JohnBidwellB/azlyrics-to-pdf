from .azlyrics import *
